import serial
import serial.tools.list_ports
import requests
import time
from datetime import datetime

API_KEY = "cff69c0dd777fa73518805a72bd697ce"
CITY = "Izmir"
COUNTRY = "TR"

WEATHER_CACHE = None
WEATHER_CACHE_TIME = 0
WEATHER_TTL = 600

def find_esp_port():
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        desc = p.description.upper()
        if any(kw in desc for kw in ['USB', 'ESP32', 'CP210', 'CH340', 'SERIAL']):
            return p.device
    return ports[0].device if ports else None

def get_weather():
    global WEATHER_CACHE, WEATHER_CACHE_TIME
    now = time.time()
    if WEATHER_CACHE and (now - WEATHER_CACHE_TIME) < WEATHER_TTL:
        return WEATHER_CACHE

    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={CITY},{COUNTRY}&appid={API_KEY}&units=metric"
        r = requests.get(url, timeout=10)
        data = r.json()
        temp = round(data['main']['temp'])
        weather = data['weather'][0]['main']
        icon = data['weather'][0]['icon']

        icon_map = {
            '01d': 'Clear', '01n': 'Clear',
            '02d': 'P.Cloudy', '02n': 'P.Cloudy',
            '03d': 'Cloudy', '03n': 'Cloudy',
            '04d': 'Overcast', '04n': 'Overcast',
            '09d': 'Showers', '09n': 'Showers',
            '10d': 'Rain', '10n': 'Rain',
            '11d': 'Thunder', '11n': 'Thunder',
            '13d': 'Snow', '13n': 'Snow',
            '50d': 'Fog', '50n': 'Fog',
        }
        desc = icon_map.get(icon, weather)
        result = f"{desc} {temp}\xb0C {CITY}"
        WEATHER_CACHE = result
        WEATHER_CACHE_TIME = now
        return result
    except Exception as e:
        return f"Weather N/A"

def send_status(ser):
    now = datetime.now()
    time_str = now.strftime("%H:%M")
    date_str = now.strftime("%a %d %b %Y")
    weather_str = get_weather()
    line = f"S|{time_str}|{date_str}|{weather_str}\n"
    ser.write(line.encode())
    print(f"[{time_str}] Sent: {date_str} | {weather_str}")

def main():
    print("=" * 40)
    print("  Macropad Companion v1.0")
    print("  ESP32-S3'e saat + hava gonderir")
    print("=" * 40)

    port = find_esp_port()
    if not port:
        print("\nESP32 bulunamadi. COM portlari:")
        for p in serial.tools.list_ports.comports():
            print(f"  {p.device}: {p.description}")
        port = input("\nPort adini elle gir (orn: COM3): ").strip()

    print(f"\nBaglaniyor: {port}...")
    ser = serial.Serial(port, 115200, timeout=2)
    time.sleep(2.5)
    ser.reset_input_buffer()
    print("Baglandi! Status gonderiliyor...\n")

    send_status(ser)
    last_send = time.time()

    try:
        while True:
            now = time.time()
            if now - last_send >= 30:
                send_status(ser)
                last_send = now
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nKapatiliyor...")
    finally:
        ser.close()
        print("Baglanti kapandi.")

if __name__ == "__main__":
    main()
