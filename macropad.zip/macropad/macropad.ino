#define LGFX_USE_V1
#include <LovyanGFX.hpp> // LovyanGFX kütüphanesi 
#include "USB.h"
#include "USBHIDKeyboard.h"
#include "USBHIDConsumerControl.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include "time.h"

USBHIDKeyboard Keyboard;
USBHIDConsumerControl ConsumerControl;

// WI-FI VE HAVA DURUMU AYARLARI
const char* ssid     = "FiberHGW_TPFEAE";
const char* password = "mzTHKz4Na7T9";
const char* apiKey   = "cff69c0dd777fa73518805a72bd697ce";
const char* city     = "Izmir,TR";

// NTP Saat Ayarları (GMT+3 Türkiye Saati için)
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 3 * 3600; 
const int   daylightOffset_sec = 0;   

// Renk Tanımlamaları
#define COLOR_RED   0xF800
#define COLOR_WHITE 0xFFFF

// =========================================================================
// LOVYANGFX DONANIMSAL EKRAN YAPILANDIRMASI (40 MHz Donanımsal SPI)
// =========================================================================
class LGFX : public lgfx::LGFX_Device
{
  lgfx::Panel_ILI9341 _panel_instance;
  lgfx::Bus_SPI       _bus_instance;
public:
  LGFX(void)
  {
    {
      auto cfg = _bus_instance.config();
      cfg.spi_host = SPI2_HOST;     
      cfg.spi_mode = 0;
      cfg.freq_write = 40000000;    // 40 MHz yazma hızı
      cfg.freq_read  = 16000000;
      cfg.pin_sclk = 12;            // TFT_SCLK
      cfg.pin_mosi = 13;            // TFT_MOSI
      cfg.pin_miso = -1;
      cfg.pin_dc   = 11;            // TFT_DC
      _bus_instance.config(cfg);
      _panel_instance.setBus(&_bus_instance);
    }
    {
      auto cfg = _panel_instance.config();
      cfg.pin_cs           = 10;    // TFT_CS
      cfg.pin_rst          = 9;     // TFT_RST
      cfg.pin_busy         = -1;
      cfg.memory_width     = 240;
      cfg.memory_height    = 320;
      cfg.panel_width      = 240;
      cfg.panel_height     = 320;
      cfg.offset_x         = 0;
      cfg.offset_y         = 0;
      cfg.offset_rotation  = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits  = 1;
      cfg.readable         = false;
      cfg.invert           = false;
      cfg.rgb_order        = false;
      cfg.dlen_16bit       = false;
      cfg.bus_shared       = false;
      _panel_instance.config(cfg);
    }
    setPanel(&_panel_instance);
  }
};
LGFX tft; 

// BUTON VE GPIO TABLOSU
const int NUM_BUTTONS = 8;
const int buttonPins[NUM_BUTTONS] = {1, 2, 3, 7, 8, 14, 15, 16};

// ENCODER PİNLERİ
const int pinCLK = 4;
const int pinDT = 5;
const int pinSW = 6;

// Durum takip dizileri
bool lastButtonStates[NUM_BUTTONS];

// Encoder durum takip değişkenleri
int lastStateCLK;
bool lastButtonSWState = HIGH;
unsigned long lastEncoderTime = 0;
const unsigned long encoderDebounce = 1;

// Ekrandaki Veriler (İnternetten Alınanlar)
String pcTime = "--:--";
String pcDate = "Updating...";
String pcWeather = "Fetching Weather...";
int pcVolume = 50; 

// Ekran Yenileme Kontrol Değişkenleri
String lastPrintedTime = "";
String lastPrintedDate = "";
String lastPrintedWeather = "";
int lastPrintedVol = -1;
char lastAction[32] = "";

// Zamanlayıcı Kontrolleri
unsigned long lastTimeCheck = 0;       
unsigned long lastWeatherCheck = 0;    
const unsigned long weatherInterval = 900000; // 15 dakika

// Ses Barı Popup Zamanlayıcı Değişkenleri
bool showVolumeOverlay = false;
bool lastVolumeOverlayState = false;
bool forceFullLowerRedraw = true; 
unsigned long lastVolumeChangeTime = 0;
const unsigned long volumeOverlayDuration = 3000; // 3 saniye

#ifndef KEY_PRINT_SCREEN
#define KEY_PRINT_SCREEN 206
#endif

// İngilizce Ay ve Gün İsimleri Eşlemesi
const char* englishMonths[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
const char* englishDays[]   = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

// Alt paneldeki işlem adını günceller
void updateScreen(const char* actionName) {
  if (strcmp(lastAction, actionName) == 0) {
    return; 
  }
  strncpy(lastAction, actionName, sizeof(lastAction) - 1);
  if (!showVolumeOverlay) {
    forceFullLowerRedraw = true; 
  }
}

// Türkçe Q Klavye için karakter dönüştürücü
void keyboardPrintTR(const char* str) {
  for (int i = 0; str[i] != '\0'; i++) {
    char c = str[i];
    switch (c) {
      case ':': Keyboard.print('?'); break;
      case '/': Keyboard.print('&'); break;
      case '.': Keyboard.print('/'); break;
      case 'i': Keyboard.print('\''); break;
      default: Keyboard.print(c); break;
    }
  }
}

// Windows üzerinde komut çalıştırma fonksiyonu
void runCommand(const char* command) {
  Keyboard.press(KEY_LEFT_GUI); 
  Keyboard.press('r');
  delay(180); 
  Keyboard.releaseAll();
  delay(400); 

  keyboardPrintTR(command);
  
  delay(150);
  Keyboard.write(KEY_RETURN);
}

// İnternetten Tarih ve Saat Bilgilerini Çeker
void updateTimeFromNTP() {
  struct tm timeinfo;
  if (getLocalTime(&timeinfo)) {
    char timeHourMin[6];
    strftime(timeHourMin, sizeof(timeHourMin), "%H:%M", &timeinfo);
    pcTime = String(timeHourMin);

    // Tarihi İngilizce formatta oluşturuyoruz
    pcDate = String(timeinfo.tm_mday) + " " + englishMonths[timeinfo.tm_mon] + " " + englishDays[timeinfo.tm_wday];
  }
}

// İnternetten İzmir Hava Durumunu Çeker
void updateWeatherFromAPI() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    // İngilizce hava açıklamaları için "&lang=en" parametresini kullanıyoruz
    String url = "http://api.openweathermap.org/data/2.5/weather?q=" + String(city) + "&appid=" + String(apiKey) + "&units=metric&lang=en";
    http.begin(url);
    
    int httpCode = http.GET();
    if (httpCode > 0) {
      String payload = http.getString();
      
      int tempIndex = payload.indexOf("\"temp\":");
      int descIndex = payload.indexOf("\"description\":\"");
      
      String tempVal = "";
      String descVal = "";
      
      if (tempIndex != -1) {
        int endTempIndex = payload.indexOf(",", tempIndex);
        float t = payload.substring(tempIndex + 7, endTempIndex).toFloat();
        tempVal = String((int)round(t)) + "C";
      }
      
      if (descIndex != -1) {
        int endDescIndex = payload.indexOf("\"", descIndex + 15);
        descVal = payload.substring(descIndex + 15, endDescIndex);
        
        if (descVal.length() > 0) {
          descVal[0] = toupper(descVal[0]);
        }
      }
      pcWeather = "Izmir: " + tempVal + " - " + descVal;
    }
    http.end();
  }
}

// Arayüz Çizim Motoru
void drawModernUI() {
  // 1. ÜST YARIM - ORTALANMIŞ SAAT, TARİH VE HAVA DURUMU
  if (!showVolumeOverlay) {
    if (pcTime != lastPrintedTime) {
      tft.fillRect(0, 32, 320, 42, COLOR_RED); 
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(5);
      
      int xPos = (320 - (pcTime.length() * 30)) / 2;
      tft.setCursor(xPos, 35);
      tft.print(pcTime);
      lastPrintedTime = pcTime;
    }
    
    if (pcDate != lastPrintedDate) {
      tft.fillRect(0, 82, 320, 18, COLOR_RED); 
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(2); 
      
      int xPos = (320 - (pcDate.length() * 12)) / 2;
      tft.setCursor(xPos, 84);
      tft.print(pcDate);
      lastPrintedDate = pcDate;
    }

    if (pcWeather != lastPrintedWeather) {
      tft.fillRect(0, 107, 320, 18, COLOR_RED); 
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(2);

      int xPos = (320 - (pcWeather.length() * 12)) / 2;
      tft.setCursor(xPos, 108);
      tft.print(pcWeather); 
      lastPrintedWeather = pcWeather;
    }
  }

  // ==========================================
  // 2. ALT YARIM - ULTRA HIZLI GEÇİŞ MOTORU
  // ==========================================
  if (showVolumeOverlay) {
    if (lastVolumeOverlayState != showVolumeOverlay) {
      tft.fillRect(10, 140, 300, 85, COLOR_RED); 
      tft.drawRect(10, 140, 300, 85, COLOR_WHITE); 
      
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(2);
      tft.setCursor(25, 153);
      tft.print("VOLUME LEVEL");
      
      tft.drawRect(25, 180, 210, 20, COLOR_WHITE); 
      
      lastVolumeOverlayState = showVolumeOverlay;
      lastPrintedVol = -1; 
    }
    
    if (pcVolume != lastPrintedVol) {
      tft.fillRect(27, 182, 206, 16, COLOR_RED);
      
      int fillWidth = (pcVolume * 206) / 100;
      if (fillWidth > 0) {
        tft.fillRect(27, 182, fillWidth, 16, COLOR_WHITE); 
      }
      
      tft.fillRect(245, 180, 60, 22, COLOR_RED);
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(2);
      tft.setCursor(245, 183);
      tft.print(String(pcVolume) + "%");
      
      lastPrintedVol = pcVolume;
    }

    if (millis() - lastVolumeChangeTime > volumeOverlayDuration) {
      showVolumeOverlay = false;
    }
  } else {
    if (forceFullLowerRedraw || lastVolumeOverlayState != showVolumeOverlay) {
      tft.fillRect(10, 140, 300, 85, COLOR_RED); 
      tft.drawRect(10, 140, 300, 85, COLOR_WHITE); 
      
      tft.setTextColor(COLOR_WHITE);
      tft.setTextSize(2);
      tft.setCursor(25, 175);
      tft.print("Action: ");
      tft.print(lastAction);
      
      forceFullLowerRedraw = false;
      lastVolumeOverlayState = showVolumeOverlay;
      lastPrintedVol = -1; 
    }
  }
}

void setup() {
  // 1. Ekranı Başlat
  tft.init();
  tft.setRotation(1); // Landscape yönü
  tft.fillScreen(COLOR_RED); 
  tft.setTextColor(COLOR_WHITE);

  // 2. Başlangıç Ekranı Çizimleri (Tümü Ortalı)
  int xVal = (320 - (String("MACROPAD V1").length() * 18)) / 2;
  tft.setCursor(xVal, 50);
  tft.setTextSize(3);
  tft.print("MACROPAD V1");
  
  xVal = (320 - (String("developed by htekin.com").length() * 12)) / 2;
  tft.setCursor(xVal, 90);
  tft.setTextSize(2);
  tft.print("developed by htekin.com");

  xVal = (320 - (String("Connecting Wi-Fi...").length() * 12)) / 2;
  tft.setCursor(xVal, 145);
  tft.setTextSize(2);
  tft.print("Connecting Wi-Fi...");

  // 3. Wi-Fi Bağlantısını Başlat
  WiFi.begin(ssid, password);
  unsigned long startAttemptTime = millis();
  
  while (WiFi.status() != WL_CONNECTED && millis() - startAttemptTime < 10000) {
    delay(500);
  }

  tft.fillRect(0, 140, 320, 30, COLOR_RED); // Wi-Fi durum satırını temizle
  
  if (WiFi.status() == WL_CONNECTED) {
    xVal = (320 - (String("Connected!").length() * 12)) / 2;
    tft.setCursor(xVal, 145);
    tft.setTextSize(2);
    tft.print("Connected!");
    
    configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
    delay(1000);
    updateTimeFromNTP();
    updateWeatherFromAPI();
  } else {
    xVal = (320 - (String("Wi-Fi Failed!").length() * 12)) / 2;
    tft.setCursor(xVal, 145);
    tft.setTextSize(2);
    tft.print("Wi-Fi Failed!");
  }

  // 4. USB Klavyeyi ve Medya Kontrolünü Başlat
  Keyboard.begin();
  ConsumerControl.begin();
  USB.begin();

  // 5. Buton Pinlerini Tanımla (Dahili Pull-up aktif)
  for (int i = 0; i < NUM_BUTTONS; i++) {
    pinMode(buttonPins[i], INPUT_PULLUP);
  }

  // 6. Encoder Pinlerini Tanımla
  pinMode(pinCLK, INPUT_PULLUP);
  pinMode(pinDT, INPUT_PULLUP);
  pinMode(pinSW, INPUT_PULLUP);

  lastStateCLK = digitalRead(pinCLK);

  delay(1000); 

  // 7. İlk Buton Durumlarını Kaydet
  for (int i = 0; i < NUM_BUTTONS; i++) {
    lastButtonStates[i] = digitalRead(buttonPins[i]);
  }

  // Ekranı temizle ve "Sistem Aktif" uyarısını ortala
  tft.fillRect(0, 140, 320, 30, COLOR_RED);
  xVal = (320 - (String("System Active").length() * 12)) / 2;
  tft.setCursor(xVal, 145);
  tft.setTextSize(2);
  tft.print("System Active");
  delay(1000);

  tft.fillRect(0, 0, 320, 240, COLOR_RED); 
  
  strncpy(lastAction, "Idle", sizeof(lastAction) - 1);
}

void loop() {
  // 1. Periyodik Saat Güncellemesi (200ms'de bir kontrol edilir)
  if (millis() - lastTimeCheck > 200) {
    updateTimeFromNTP();
    lastTimeCheck = millis();
  }

  // 2. Hava durumunu her 15 dakikada bir güncelle
  if (millis() - lastWeatherCheck > weatherInterval || lastWeatherCheck == 0) {
    updateWeatherFromAPI();
    lastWeatherCheck = millis();
  }

  drawModernUI();    

  // ==========================================
  // 1. ENCODER DÖNÜŞ TAKİBİ (SES KONTROLÜ)
  // ==========================================
  int currentStateCLK = digitalRead(pinCLK);
  
  if (currentStateCLK != lastStateCLK && currentStateCLK == LOW) {
    if (millis() - lastEncoderTime > encoderDebounce) {
      if (digitalRead(pinDT) != currentStateCLK) {
        ConsumerControl.press(CONSUMER_CONTROL_VOLUME_DECREMENT);
        ConsumerControl.release();
        
        if (pcVolume > 0) pcVolume -= 2;
        lastVolumeChangeTime = millis(); 
        showVolumeOverlay = true;
      } else {
        ConsumerControl.press(CONSUMER_CONTROL_VOLUME_INCREMENT);
        ConsumerControl.release();
        
        if (pcVolume < 100) pcVolume += 2;
        lastVolumeChangeTime = millis(); 
        showVolumeOverlay = true;
      }
      lastEncoderTime = millis();
    }
  }
  lastStateCLK = currentStateCLK;

  // ==========================================
  // 2. ENCODER BUTON TAKİBİ (SW - PLAY/PAUSE)
  // ==========================================
  bool currentButtonSWState = digitalRead(pinSW);
  
  if (lastButtonSWState == HIGH && currentButtonSWState == LOW) {
    delay(50);
    if (digitalRead(pinSW) == LOW) {
      updateScreen("Play / Pause");
      ConsumerControl.press(CONSUMER_CONTROL_PLAY_PAUSE);
      delay(80); 
      ConsumerControl.release();
      
      while (digitalRead(pinSW) == LOW) {
        delay(10);
      }
    }
  }
  lastButtonSWState = currentButtonSWState;

  // ==========================================
  // 3. DIŞ BUTONLARIN TAKİBİ
  // ==========================================
  for (int i = 0; i < NUM_BUTTONS; i++) {
    bool currentButtonState = digitalRead(buttonPins[i]);
    
    if (lastButtonStates[i] == HIGH && currentButtonState == LOW) {
      delay(50);
      
      if (digitalRead(buttonPins[i]) == LOW) {
        
        switch (i) {
          case 0:
            updateScreen("Google Chrome");
            runCommand("chrome"); 
            break;
            
          case 1:
            updateScreen("Google Drive");
            runCommand("chrome https://drive.google.com"); 
            break;
            
          case 2:
            updateScreen("Google Calendar");
            runCommand("chrome https://calendar.google.com");
            break;
            
          case 3:
            updateScreen("Google Keep");
            runCommand("chrome https://keep.google.com");
            break;
            
          case 4:
            updateScreen("File Explorer");
            Keyboard.press(KEY_LEFT_GUI);
            Keyboard.press('e');
            delay(100);
            Keyboard.releaseAll();
            break;
            
          case 5:
            updateScreen("Copy");
            Keyboard.press(KEY_LEFT_CTRL);
            Keyboard.press('c');
            delay(100);
            Keyboard.releaseAll();
            break;
            
          case 6:
            updateScreen("Paste");
            Keyboard.press(KEY_LEFT_CTRL);
            Keyboard.press('v');
            delay(100);
            Keyboard.releaseAll();
            break;
            
          case 7:
            updateScreen("Print Screen");
            Keyboard.press(KEY_PRINT_SCREEN);
            delay(100);
            Keyboard.releaseAll();
            break;
        }
        
        while (digitalRead(buttonPins[i]) == LOW) {
          delay(10);
        }
        currentButtonState = HIGH;
      }
    }
    lastButtonStates[i] = currentButtonState;
  }
}